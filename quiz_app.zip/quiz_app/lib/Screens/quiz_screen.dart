import 'package:flutter/material.dart';
import 'package:quiz_app/Models/color.dart';
import '../Component/quiz.dart';
import '../Component/result.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({Key? key}) : super(key: key);

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {

  int _questionIndex = 0;
  int _score = 0;

  List<Map<String, Object>> _questions = [
    {
      'questionText': '1) In what country was Elon Musk born?',
      'answers': [
        {'text': 'South Africa', 'correct': true},
        {'text': 'America', 'correct': false},
        {'text': 'England', 'correct': false},
        {'text': 'Portgal', 'correct': false},
      ],
    },
    {
      'questionText': '2) What planet is closest to the sun?',
      'answers': [
        {'text': 'Mars', 'correct': false},
        {'text': 'Mercury', 'correct': true},
        {'text': 'Ploto', 'correct': false},
        {'text': 'Neptune', 'correct': false},
      ],
    },
    {
      'questionText': '3) What phone company produced the 3310??',
      'answers': [
        {'text': 'SamSung', 'correct': false},
        {'text': 'Oppo', 'correct': false},
        {'text': 'Nokia', 'correct': true},
        {'text': 'Motrolla', 'correct': false},
      ],
    },
    {
      'questionText': '4) What is the capital of Ireland?',
      'answers': [
        {'text': 'Berlin', 'correct': false},
        {'text': 'Dublin', 'correct': true},
        {'text': 'Denver', 'correct': false},
        {'text': 'Lisban', 'correct': false},
      ],
    },
    {
      'questionText': '5) On what continent would you find the city of Baku??',
      'answers': [
        {'text': 'Europe', 'correct': false},
        {'text': 'Australia', 'correct': true},
        {'text': 'Africa', 'correct': false},
        {'text': 'Asia', 'correct': true},
      ],
    },
  ];

  void _answerQuestion(bool isCorrect) {
    if (isCorrect) {
      setState(() {
        _score++;
      });
    }

    setState(() {
      _questionIndex++;
    });
  }

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: background,
        body: Column(
          children: [
            SizedBox(
                  height: 35,
                ),
                Center(child: Text('First Quiz',style: TextStyle(
                    color: neutral,fontSize: 26,fontWeight: FontWeight.bold
                ))),
            Expanded(
              child: Container(
                child: _questionIndex < _questions.length
                    ? Quiz(
                  questionIndex: _questionIndex,
                  questions: _questions,
                  answerQuestion: _answerQuestion,
                )
                    : Result(
                  score: _score,
                  // resetQuiz: _resetQuiz,
                ),

              ),
            ),
          ],
        )


      );
  }
}

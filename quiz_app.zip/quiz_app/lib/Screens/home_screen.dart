import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/Models/color.dart';
import 'package:quiz_app/Widgets/button.dart';
import 'package:quiz_app/utils/routes_name.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      backgroundColor: background,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: background,
        actions: [
          IconButton(onPressed: (){
            FirebaseAuth auth=FirebaseAuth.instance;
            auth.signOut().then((value) {
              // SessionController().userId='';
              Navigator.pushNamed(context, RoutesName.loginScreen);
            });
          }, icon: const Icon(Icons.logout,color: Colors.white,))
        ],
      ),
      body: Column(

        children: [
          Center(child: Text('Quiz App',style: TextStyle(color: neutral,fontSize: 64,fontWeight: FontWeight.bold),)),
          const SizedBox(height: 10,),
          Center(
              child: Text('   Challange your mind to think \n                      sharp!',style: TextStyle(color: neutral,fontSize: 22,fontWeight: FontWeight.normal),)),
          const SizedBox(
            height: 25,
          ),
          Container(
            height: 300,
            width: 300,
            child: const Image(image: AssetImage('assets/004.png')),
          ),
          const SizedBox(
            height: 30,
          ),
           InkWell(
             onTap: (){
               Navigator.pushNamed(context, RoutesName.quizScreen);
             },
               child: Button(title: 'Start Quiz'))
        ],
      ),

    );
  }
}

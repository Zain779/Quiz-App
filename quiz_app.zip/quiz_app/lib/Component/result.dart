
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:quiz_app/Models/color.dart';
import 'package:quiz_app/Widgets/button.dart';
import 'package:quiz_app/utils/routes_name.dart';



class Result extends StatelessWidget {
  final int score;
  // final Function resetQuiz;

  Result({required this.score, //required this.resetQuiz
  });
  DatabaseReference ref=FirebaseDatabase.instance.ref().child('User');
  FirebaseAuth auth=FirebaseAuth.instance;

  void result(){
    ref.child(auth.currentUser!.uid.toString()).update({
      'Score': score
    });

  }
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Quiz Completed!',
            style: TextStyle(fontSize: 25,color: neutral),
          ),
          SizedBox(height: 10),
          InkWell(
            onTap: (){
              result();
            },
            child: Text(
              'Score: $score/5',
              style: TextStyle(fontSize: 20,color: neutral),
            ),
          ),
          SizedBox(height: 10),
          InkWell(
            onTap: () // => resetQuiz(),
            {Navigator.pushNamed(context, RoutesName.homeScreen);},
              child: Button(title: 'Start Again',)),
          // ElevatedButton(
          //   onPressed: () => resetQuiz(),
          //   child: Text('Restart Quiz'),
          // ),
        ],
      ),
    );
  }
}
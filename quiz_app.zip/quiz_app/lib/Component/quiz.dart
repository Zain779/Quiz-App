import 'package:flutter/material.dart';
import 'package:quiz_app/Models/color.dart';

class Quiz extends StatelessWidget {
  final int questionIndex;
  final List<Map<String, Object>> questions;
  final Function(bool) answerQuestion;

  Quiz({
    required this.questionIndex,
    required this.questions,
    required this.answerQuestion,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: ListView.builder(
          itemCount: 1,
            itemBuilder: (context,index){
            return Column(
              children: [
                SizedBox(
                  height: 35,
                ),
                Text(
                  questions[0]['questionText'] as String,
                  style: TextStyle(fontSize: 20,color: neutral),
                ),
                Option(questionIndex: 0, questions: questions, answerQuestion: answerQuestion),

                Text(
                  questions[1]['questionText'] as String,
                  style: TextStyle(fontSize: 20,color: neutral),
                ),
                SizedBox(height: 10),
                Option(questionIndex: 1, questions: questions, answerQuestion: answerQuestion),
                Text(
                  questions[2]['questionText'] as String,
                  style: TextStyle(fontSize: 20,color: neutral),
                ),
                Option(questionIndex: 2, questions: questions, answerQuestion: answerQuestion),
                Text(
                  questions[3]['questionText'] as String,
                  style: TextStyle(fontSize: 20,color: neutral),
                ),
                Option(questionIndex: 3, questions: questions, answerQuestion: answerQuestion),
                Text(
                  questions[4]['questionText'] as String,
                  style: TextStyle(fontSize: 20,color: neutral),
                ),
                Option(questionIndex: 4, questions: questions, answerQuestion: answerQuestion),

                SizedBox(height: 10),
                // ...(questions[questionIndex]['answers'] as List<Map<String, Object>>)
                //     .map((e) {
                //   return Column(
                //     children: [
                //       SizedBox(height: 8,),
                //       InkWell(
                //         onTap: () => answerQuestion(e['correct'] as bool),
                //         child: Container(
                //           width: 320,
                //           height: 50,
                //           decoration: BoxDecoration(
                //             color: neutral,
                //             borderRadius: BorderRadius.circular(10),
                //           ),
                //           child: Center(
                //               child: Text( e['text'] as String,
                //                 style: const TextStyle(
                //                   fontSize: 22,
                //                   fontWeight: FontWeight.bold,
                //                   fontFamily: 'Rubik Regular',
                //                   color: Color(0xFF1d1a5f),
                //                 ),
                //               )
                //           ),
                //         ),
                //       ),
                //     ],
                //   );
                //
                //
                // })
                // .toList(),
              ],
            );
            })
      ),
    );
  }
}

class Option extends StatefulWidget {
  final int questionIndex;
  final List<Map<String, Object>> questions;
  final Function(bool) answerQuestion;
  const Option({Key? key,
    required this.questionIndex,
    required this.questions,
    required this.answerQuestion,
  }) : super(key: key);

  @override
  State<Option> createState() => _OptionState();
}

class _OptionState extends State<Option> {
  bool SelectedItem=false;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          SizedBox(height: 10),
          ...(widget.questions[widget.questionIndex]['answers'] as List<Map<String, Object>>)
              .map((e) {
            return Column(
              children: [
                SizedBox(height: 8,),
                InkWell(
                  onTap: () //=> widget.answerQuestion(e['correct'] as bool),
                {
                  SelectedItem=true;
                  setState(() {
                    widget.answerQuestion(e['correct'] as bool);
                  });

                },
                  child: SelectedItem==false? Container(
                    width: 320,
                    height: 50,
                    decoration: BoxDecoration(
                      color: neutral,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                        child: Text( e['text'] as String,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rubik Regular',
                            color: Color(0xFF1d1a5f),
                          ),
                        )
                    ),
                  ):
                  Container(
                    width: 320,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                        child: Text( e['text'] as String,
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Rubik Regular',
                            color: Color(0xFF1d1a5f),
                          ),
                        )
                    ),
                  )
                ),
              ],
            );


          }),
        ],
      ),

    );
  }
}

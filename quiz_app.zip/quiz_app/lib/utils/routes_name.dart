

class RoutesName{
  static const String loginScreen='login_screen';
  static const String signupScreen='signup_screen';
  static const String homeScreen='home_screen';
  static const String quizScreen='quiz_screen';
}
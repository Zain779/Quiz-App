import 'package:flutter/material.dart';

final Color correct=Colors.green;
final Color incorrect=Colors.red;
final Color neutral=Color(0xFFE7E7E7);
final Color background=Color(0xFF1d1a5f);
final Color buttonColor=Color(0xff40e5ed);